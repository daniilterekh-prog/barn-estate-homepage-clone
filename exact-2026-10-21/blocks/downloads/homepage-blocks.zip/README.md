# Блоки главной BARN Estate

Начните с INSTALL.md. Готовые пакеты находятся в homepage-blocks/. Параметры оформления — в UI-KIT.md.
