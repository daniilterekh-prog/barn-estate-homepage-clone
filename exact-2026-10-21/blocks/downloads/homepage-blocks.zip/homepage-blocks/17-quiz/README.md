# Квиз обращения к эксперту

## Что вставить

- **Одним фрагментом:** содержимое [paste.html](paste.html) целиком.
- **Раздельно:** [block.html](block.html), [block.css](block.css), [block.js](block.js) и папку [assets/](assets/).
- **Проверить:** открыть [index.html](index.html).

## Поведение

Автономный запуск актуальной формы: вопросы о задаче/направлении/деталях, ветка амбассадоров, каналы Telegram/WhatsApp/MAX/Звонок. На мобильном Руслан по пояс с журналом, голова целиком. Валюты только ₽/$/€.

## Подключение

Формы и поиск требуют подключения к основному сайту. Общая инструкция, отправка форм, поиск и приёмка: [INSTALL.md](https://github.com/daniilterekh-prog/barnes-sites/blob/main/main-site/pages/home/exact-2026-10-21/INSTALL.md). Шрифты, цвета, интервалы и кнопки: [UI-KIT.md](https://github.com/daniilterekh-prog/barnes-sites/blob/main/main-site/pages/home/exact-2026-10-21/UI-KIT.md).

Сохранить классы, data-v/data-атрибуты, ARIA и JSON в HTML. Источники изображений и лицензии — в manifest.json и assets/.

[content.json](content.json) — тексты и ссылки; [design.json](design.json) — параметры оформления; [manifest.json](manifest.json) — состав пакета.
