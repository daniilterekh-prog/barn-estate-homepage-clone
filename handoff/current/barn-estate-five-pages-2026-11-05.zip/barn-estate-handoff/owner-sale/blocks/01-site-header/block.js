import {initBlock} from '../../code/js/blocks-runtime.js';
initBlock(document.querySelector('[data-handoff-block="01-site-header"]'),{page:"owner-sale",kind:"site-header",preview:document.body.hasAttribute('data-block-preview')});
