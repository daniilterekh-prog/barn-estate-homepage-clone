import {initBlock} from './blocks-runtime.js';
initBlock(document.querySelector('[data-handoff-block="01-site-header"]'),{page:"partners",kind:"site-header",preview:document.body.hasAttribute('data-block-preview')});
