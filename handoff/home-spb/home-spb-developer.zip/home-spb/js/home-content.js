/* Eyebrows from «ЭКСТРА ФИНАЛЬНОЕ ТЗ», Главная, read 2026-10-27.
 * Runs after Nuxt hydration; leaves the immutable capture untouched.
 */
(() => {
  if (window.__barnesHomeContent) return;
  window.__barnesHomeContent = {pending: true};
  const saleImageBase = new URL('assets/', document.currentScript.src).href;
  const floatingPortrait = new URL('assets/ludmila-belousova-bw.webp', document.currentScript.src).href;
  const roles = [
    ['.services-section__header', '.services-section__titles', 'BARN ESTATE · SAINT PETERSBURG', '.services-section__eyebrow'],
    ['.barnes-choice__heading', '.barnes-choice__title', 'Недвижимость по направлениям'],
    ['.departments-section__heading', '.departments-section__title', 'Выбрать направление'],
    ['.reviews-section__intro', '.reviews-section__title', 'Репутация BARN Estate', '.reviews-section__eyebrow'],
    ['.team-section__intro', '.team-section__title', 'Эксперты по недвижимости'],
    ['.partners-section__intro', '.partners-section__title', 'Девелоперы Петербурга'],
    ['.office-contact__copy', 'h2', 'Контакт'],
    ['.news-section__header', '.news-section__title', 'Медиа BARN Estate', '.news-section__eyebrow'],
    ['.newsletter-cta__copy', 'h2', 'Рассылка BARN Estate'],
    ['.about-company__content', '.about-company__title', 'О компании']
  ];
  const oldBrand = /(?<![\w@./-])barnes(?:\s+(?:moscow|international\s+realty))?(?![\w@./-])|(?<![а-яё])барн(?:с|ес)(?![а-яё])/giu;
  const brandText = value => value.replace(oldBrand, 'BARN Estate');
  function refreshBrand() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement?.closest('script,style,textarea,[data-preserve-brand]')) continue;
      const text = brandText(node.nodeValue);
      if (text !== node.nodeValue) node.nodeValue = text;
    }
    for (const el of document.querySelectorAll('[alt],[title],[aria-label],[placeholder],meta[content]')) {
      if (el.closest('[data-preserve-brand]')) continue;
      for (const attr of ['alt','title','aria-label','placeholder', ...(el.tagName === 'META' ? ['content'] : [])]) {
        if (!el.hasAttribute(attr)) continue;
        const text = el.getAttribute(attr), updated = brandText(text);
        if (updated !== text) el.setAttribute(attr, updated);
      }
    }
    const title = brandText(document.title);
    if (document.title !== title) document.title = title;
  }
  // Regional identity and copy belong only to this independent SPb page.
  const regionalCopy = {
  ".services-section__description": "BARN Estate Saint Petersburg помогает выбрать недвижимость для жизни, отдыха и инвестиций. Подбираем квартиры в историческом центре и новых жилых кварталах Петербурга, загородные дома в Ленинградской области. Сопровождаем покупку, продажу и аренду с вниманием к вашим задачам и конфиденциальности.",
  ".about-company__intro": "BARN Estate Saint Petersburg помогает покупать, продавать и арендовать элитную недвижимость Петербурга и Ленинградской области. Учитываем ваш образ жизни, требования к дому и окружению, сопровождаем выбор объекта и сделку на каждом этапе.",
  ".team-section__description": "Эксперты BARN Estate помогают оценить объект, сравнить предложения и пройти все этапы сделки. К каждому запросу подключаем специалиста по нужному направлению — от городской квартиры до загородного дома.",
  ".partners-section__description": "Изучаем проекты петербургских застройщиков: сравниваем архитектуру, расположение, планировки и условия покупки. Помогаем выбрать дом с учётом ваших задач, привычных маршрутов и требований к окружению.",
  ".office-contact__lead": "Приглашаем в петербургский офис на набережной Мойки: обсудим ваши планы и подберём подходящий формат недвижимости."
};
  function refreshSpbIdentity() {
    for (const [selector, text] of Object.entries(regionalCopy)) {
      const element = document.querySelector(selector);
      if (element && element.textContent.replace(/\u00a0/g, ' ') !== text.replace(/\u00a0/g, ' ')) element.textContent = text;
    }
    for (const host of document.querySelectorAll('.site-header__logo,.owner-sale-sticky__logo,.site-footer__logo,.about-company__brand')) {
      if (!host.querySelector('img')) continue;
      host.querySelectorAll('.spb-brand-caption').forEach(caption => caption.remove());
      const label = 'BARN Estate' + (host.tagName === 'A' ? ' — на главную' : '');
      if (host.getAttribute('aria-label') !== label) host.setAttribute('aria-label', label);
    }
  }
  const spbCatalog=JSON.parse(document.getElementById('spb-catalog-data').textContent);
  const spbRoutes={"/": "https://barnestate-spb.ru/", "/gorodskaya-nedvizhimost/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/vtorichnaya-nedvizhimost/", "/vtorichnaya-nedvizhimost/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/vtorichnaya-nedvizhimost/", "/novostroyki/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/novostroyki/", "/kottedzhnye-poselki/": "https://barnestate-spb.ru/zagorodnaya-nedvizhimost/", "/barnes-club/": "https://barnestate-spb.ru/barn-estate-club/", "/mir-barnes/": "https://barnestate-spb.ru/mir-barn-estate/", "/zhilye-kompleksy/": "https://barnestate-spb.ru/zhilye-kompleksy/", "/gorodskaya-nedvizhimost/novostroyki/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/novostroyki/", "/gorodskaya-nedvizhimost/vtorichnaya-nedvizhimost/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/vtorichnaya-nedvizhimost/", "/zagorodnaya-nedvizhimost/": "https://barnestate-spb.ru/zagorodnaya-nedvizhimost/", "/kommercheskaya-nedvizhimost/": "https://barnestate-spb.ru/kommercheskaya-nedvizhimost/", "/kommercheskaya-nedvizhimost/arendovat/": "https://barnestate-spb.ru/kommercheskaya-nedvizhimost/arendovat/", "/contacts/": "https://barnestate-spb.ru/contacts/", "/sobstvennikam/": "https://barnestate-spb.ru/sobstvennikam/", "/prodazha_sobstvennikam/": "https://barnestate-spb.ru/prodazha_sobstvennikam/", "/arenda_sobstvennikam/": "https://barnestate-spb.ru/arenda_sobstvennikam/", "/exclusive/": "https://barnestate-spb.ru/exclusive/", "/team/": "https://barnestate-spb.ru/team/", "/vacancies/": "https://barnestate-spb.ru/vacancies/", "/mir-barn-estate/": "https://barnestate-spb.ru/mir-barn-estate/", "/barn-estate-club/": "https://barnestate-spb.ru/barn-estate-club/", "/stily-zhizni/": "https://barnestate-spb.ru/stily-zhizni/", "/zhurnaly/": "https://barnestate-spb.ru/zhurnaly/", "/altai/": "https://barnestate-spb.ru/altai/", "/arhyz/": "https://barnestate-spb.ru/arhyz/", "/italiya/": "https://barnestate-spb.ru/italiya/", "/portugaliya/": "https://barnestate-spb.ru/portugaliya/", "/gorodskaya-nedvizhimost/filter/type_immovables-is-apartamenty/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/filter/type_immovables-is-apartamenty/", "/gorodskaya-nedvizhimost/filter/type_immovables-is-penthausy/": "https://barnestate-spb.ru/gorodskaya-nedvizhimost/filter/type_immovables-is-penthausy/"};
  function refreshLinks() {
    const destinations=new Map(spbCatalog.directions.map(item=>[item.name.toLocaleLowerCase('ru'),item.url]));
    for(const card of document.querySelectorAll('.department-card')){
      const href=destinations.get(card.querySelector('.department-card__title')?.textContent.trim().toLocaleLowerCase('ru'));
      if(href&&card.tagName==='A'&&card.href!==href){card.href=href;card.dataset.homeOriginalLink='';}
    }
    for(const link of document.querySelectorAll('a[href]')){
      const href=link.getAttribute('href');if(!href||href.startsWith('#'))continue;
      let parsed;try{parsed=new URL(href, 'https://barn-estate.ru');}catch{continue;}
      if(!/^(?:www\.)?(?:barn-estate\.ru|barnestate-spb\.ru|barnes-spb\.ru|barnes-moscow\.com)$/.test(parsed.hostname))continue;
      const target=spbRoutes[parsed.pathname];
      if(target&&link.href!==target){link.href=target;link.dataset.homeOriginalLink='';}
      else if(href.startsWith('/')&&!href.startsWith('//')){link.href=new URL(href,'https://barn-estate.ru').href;link.dataset.homeOriginalLink='';}
    }
  }
  // Keep the archived Vue router from intercepting corrected external links.
  document.addEventListener('click', event => {
    if (event.target.closest('a[data-home-original-link]')) event.stopImmediatePropagation();
  }, true);
  // The copied search shell must leave this preview for the regional catalog.
  document.addEventListener('submit', event => {
    const form=event.target;
    if(!form.matches?.('.home-hero-filters__bar'))return;
    const category=document.querySelector('.home-hero-filters__tab-group--category [aria-selected="true"]')?.textContent.trim()||'Городская';
    const key=category==='Загородная'?'country':category==='Коммерческая'?'commercial':category==='Зарубежная'?'international':'secondary';
    const direction=spbCatalog.directions.find(item=>item.key===key);
    if(!direction)return;
    event.preventDefault();event.stopImmediatePropagation();
    const rent=document.querySelector('.home-hero-filters__tab-group--deal [aria-selected="true"]')?.textContent.trim()==='Арендовать';
    const field=form.querySelector('input[placeholder*="Поиск"]');
    const query=field?.value.trim().toLocaleLowerCase('ru')||'';
    const matches=query?[...spbCatalog.projects,...spbCatalog.lots].filter(item=>String(item.lotid||item.id)===query||(item.name+' '+item.address).toLocaleLowerCase('ru').includes(query)):[];
    const target=matches.length===1?matches[0].url:rent&&key==='commercial'?'https://barnestate-spb.ru/kommercheskaya-nedvizhimost/arendovat/':direction.url;
    window.location.assign(target);
  },true);

  // Header Material Call, custom email artwork, official Yandex Maps service icon.
  const contactArtwork = {"email":"<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"contact-button__icon home-contact-artwork\" width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\" data-email-icon=\"blue-envelope\"><rect x=\"1\" y=\"5\" width=\"22\" height=\"15\" rx=\"3\" fill=\"#208bd1\"/><path d=\"M2 7.2 12 14 22 7.2V7a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1Z\" fill=\"#70bff0\"/><path d=\"m2 18 7.3-5.5L12 14l2.7-1.5L22 18v.2a.8.8 0 0 1-.8.8H2.8a.8.8 0 0 1-.8-.8Z\" fill=\"#0876b9\"/><path d=\"m2.5 7.2 8.6 5.9a1.6 1.6 0 0 0 1.8 0l8.6-5.9\" fill=\"none\" stroke=\"#fff\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>","map":"<svg class=\"contact-button__icon home-contact-artwork\" width=\"26\" height=\"26\" aria-hidden=\"true\" focusable=\"false\" data-map-icon=\"yandex\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M8 1C4.6862 1 2 3.6862 2 7C2 8.6563 2.6711 10.156 3.7565 11.2417C4.8422 12.328 7.4 13.9 7.55 15.55C7.57249 15.7974 7.7516 16 8 16C8.2484 16 8.42751 15.7974 8.45 15.55C8.6 13.9 11.1578 12.328 12.2435 11.2417C13.3289 10.156 14 8.6563 14 7C14 3.6862 11.3138 1 8 1Z\" fill=\"#FF4433\"/><path d=\"M8.00002 9.10015C9.15982 9.10015 10.1 8.15994 10.1 7.00015C10.1 5.84035 9.15982 4.90015 8.00002 4.90015C6.84023 4.90015 5.90002 5.84035 5.90002 7.00015C5.90002 8.15994 6.84023 9.10015 8.00002 9.10015Z\" fill=\"white\"/></svg>","phone":"<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"contact-button__icon home-contact-artwork\" width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"12\" fill=\"#2BB673\"/><g transform=\"translate(3 3) scale(.75)\" fill=\"white\"><path d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z\"/></g></svg>\n"};
  function refreshContactButtons() {
    for (const link of document.querySelectorAll('.office-contact__social')) {
      const href=link.getAttribute('href')||'';
      const kind=href.startsWith('mailto:')?'email':href.startsWith('tel:')?'phone':href.includes('yandex.ru/maps')?'map':null;
      if(kind==='map')link.href='https://yandex.ru/maps/?rtext=~'+encodeURIComponent('Санкт-Петербург, набережная реки Мойки, 59')+'&rtt=auto';
      if(!kind)continue;
      const label=link.querySelector(':scope > span:not(.office-contact__arrow)');
      const text=kind==='email'?'Email':kind==='map'?'На карте':null;
      if(text&&label&&label.textContent!==text)label.textContent=text;
      if(kind==='email')link.setAttribute('aria-label','Email: '+href.slice(7));
      if(kind==='map')link.setAttribute('aria-label','На карте: офис BARN Estate, Санкт-Петербург, набережная реки Мойки, 59');
      if(link.dataset.homeContactArtwork===kind)continue;
      const current=link.querySelector(':scope > svg,:scope > img');
      if(current){const holder=document.createElement('div');holder.innerHTML=contactArtwork[kind];current.replaceWith(holder.firstElementChild);link.dataset.homeContactArtwork=kind;}
    }
  }
  let observer, scheduled = false;
  function apply() {
    observer?.disconnect();
    // The standalone video section is no longer part of the homepage.
    for (const section of document.querySelectorAll('.video-section')) {
      for (const video of section.querySelectorAll('video')) {
        video.pause();
        video.removeAttribute('src');
        video.load();
      }
      section.remove();
    }
    window.__barnesHomeAbout?.refresh();
    for (const [parentSelector, headingSelector, text, existingSelector] of roles) {
      const parent = document.querySelector(parentSelector);
      const heading = parent?.querySelector(headingSelector);
      if (!heading) continue;
      let eyebrow = parent.querySelector('.home-section-eyebrow') || (existingSelector && parent.querySelector(existingSelector));
      if (!eyebrow) { eyebrow = document.createElement('p'); parent.insertBefore(eyebrow, heading); }
      eyebrow.classList.add('home-section-eyebrow');
      if (eyebrow.textContent !== text) eyebrow.textContent = text;
    }
    const heroVideo = document.querySelector('.home-hero__video');
    if (heroVideo?.hasAttribute('src')) {
      heroVideo.pause();
      heroVideo.removeAttribute('autoplay');
      heroVideo.removeAttribute('src');
      heroVideo.load();
    }
    const saleImage = document.querySelector('.services-section__item--wide .services-section__image');
    const saleVariant = innerWidth > 1920 ? ['wide',2160,396] : innerWidth > 540 ? ['desktop',2160,517] : ['mobile',1212,724];
    const saleServiceImage = saleImageBase + 'home-service-sale-gloss-' + saleVariant[0] + '.webp?v=gloss-20261031';
    if (saleImage && saleImage.src !== saleServiceImage) {
      saleImage.removeAttribute('srcset');
      saleImage.src = saleServiceImage;
      saleImage.width = saleVariant[1];
      saleImage.height = saleVariant[2];
    }
    const countryCard=[...document.querySelectorAll('.department-card')].find(card=>card.querySelector('.department-card__title')?.textContent.trim()==='Загородная');
    countryCard?.classList.add('department-card--country-clear');
    const countryImage=countryCard?.querySelector('.department-card__image');
    const countryPhoto=saleImageBase+'spb-lot-588043.webp';
    if(countryImage && countryImage.src!==countryPhoto){
      countryImage.removeAttribute('srcset');
      countryImage.src=countryPhoto;
      countryImage.width=1280;
      countryImage.height=720;
      countryImage.style.objectPosition='right center';
    }
    const recommendationTitle=document.querySelector('.barnes-choice__title');
    if(recommendationTitle && recommendationTitle.textContent!=='По рекомендации BARN\u00a0Estate')recommendationTitle.textContent='По рекомендации BARN\u00a0Estate';
    const contactTitle=document.querySelector('.office-contact__copy h2');
    if(contactTitle && contactTitle.textContent!=='СПОСОБЫ СВЯЗИ BARN ESTATE')contactTitle.textContent='СПОСОБЫ СВЯЗИ BARN ESTATE';
    const officeImage=document.querySelector('.office-contact__visual img');
    const officePhoto=saleImageBase+'home-office-estate.webp';
    if(officeImage && officeImage.src!==officePhoto){
      officeImage.removeAttribute('srcset');
      officeImage.src=officePhoto;
      officeImage.width=1563;
      officeImage.height=1006;
    }
    const avatar = document.querySelector('.floating-expert__avatar img');
    if (avatar && avatar.src !== floatingPortrait) {
      avatar.removeAttribute('srcset');
      avatar.src = floatingPortrait;
      avatar.width = 1254;
      avatar.height = 1254;
    }
    const expert = document.querySelector('.floating-expert');
    for (const [selector, text] of [['.floating-expert__name', 'Людмила Белоусова'], ['.floating-expert__label', 'Руководитель филиала BARN Estate в Санкт-Петербурге']]) {
      const element = expert?.querySelector(selector);
      if (element && element.textContent.replace(/\u00a0/g, ' ') !== text) element.textContent = text;
    }
    if (expert) {
      expert.setAttribute('aria-label', 'Людмила Белоусова');
      expert.querySelector('.floating-expert__close')?.setAttribute('aria-label', 'Скрыть карточку Людмилы Белоусовой');
      if (avatar) avatar.alt = 'Людмила Белоусова';
    }
    const copyright = document.querySelector('.site-footer__copyright');
    if (copyright && copyright.textContent !== '© 2026 BARN ESTATE · SAINT PETERSBURG') copyright.textContent = '© 2026 BARN ESTATE · SAINT PETERSBURG';
    const hours = document.querySelector('.site-footer__hours');
    if (hours && hours.textContent !== 'Ежедневно с 09:30 до 21:30') hours.textContent = 'Ежедневно с 09:30 до 21:30';
    refreshContactButtons();
    refreshLinks();
    refreshBrand();
    refreshSpbIdentity();
    window.__barnesHomeAbout?.fitLogo();
    window.__barnesHeaderContacts?.refresh();
    window.__barnesRecommendations?.refresh();
    window.__barnesOwnerForm?.refresh();
    document.body.dataset.homeSpacingReady = 'true';
    observer?.observe(document.querySelector('#__nuxt'), {childList:true, subtree:true});
  }
  function start() {
    const app = document.querySelector('#__nuxt')?.__vue_app__;
    if (!app || app.config.globalProperties.$nuxt?.isHydrating !== false) { setTimeout(start, 50); return; }
    observer = new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => { scheduled = false; apply(); });
    });
    window.__barnesHomeContent = {refresh: apply};
    apply();
  }
  window.addEventListener('resize', () => window.__barnesHomeContent?.refresh?.());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
