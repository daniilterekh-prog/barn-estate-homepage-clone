(function () {
  'use strict';

  const page = document.querySelector('.owner-sale-page');
  if (!page) return;

  document.body.classList.add('owner-sale-reference-ui');
  document.body.classList.add('barnes-header-template');
  const headerStyles = document.createElement('link');
  headerStyles.rel = 'stylesheet';
  headerStyles.href = '../css/shared-owner-header.css?v=e8e698f4b57f';
  document.head.appendChild(headerStyles);

  page.querySelectorAll('.catalog-consultation__subtitle, .catalog-consultation__mobile-title').forEach(function (title) {
    title.textContent = 'Расскажите об объекте эксперту BARN Estate';
  });
  page.querySelectorAll('.catalog-consultation__lead, .catalog-consultation__mobile-lead').forEach(function (lead) {
    lead.hidden = true;
  });

  const menuButton = document.querySelector('[aria-label="Открыть меню"]');
  let menu = document.querySelector('.site-menu');
  const sticky = page.querySelector('.owner-sale-sticky');
  const header = document.querySelector('.site-header');
  const lockBodyScroll = function () {
    const scrollbarWidth = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
    document.body.style.paddingRight = scrollbarWidth ? scrollbarWidth + 'px' : '';
    document.body.style.overflow = 'hidden';
  };
  const unlockBodyScroll = function () {
    document.body.style.paddingRight = '';
    document.body.style.overflow = '';
  };

  const syncMenuState = function () {
    if (!menuButton) return;
    const menuId = 'owner-sale-site-menu';
    if (menu) {
      menu.id = menuId;
      menu.setAttribute('aria-label', 'Основное меню');
    }
    menuButton.setAttribute('aria-controls', menuId);
    menuButton.setAttribute('aria-expanded', menu ? String(!menu.hasAttribute('hidden')) : 'false');
  };

  const enhanceHeroHeader = function () {
    const inner = header && header.querySelector('.site-header__inner');
    if (!header || !inner) return;

    header.classList.remove('site-header--no-nav');
    if (!inner.querySelector(':scope > .site-header__nav')) {
      const items = [
        ['Москва', 'https://barn-estate.ru/gorodskaya-nedvizhimost/', [['Вторичная', 'https://barn-estate.ru/vtorichnaya-nedvizhimost/'], ['Арендовать', 'https://barn-estate.ru/arendovat/'], ['Новостройки', 'https://barn-estate.ru/novostroyki/'], ['Жилые комплексы', 'https://barn-estate.ru/zhilye-kompleksy/'], ['Квартиры', 'https://barn-estate.ru/gorodskaya-nedvizhimost/kvartiry/'], ['Апартаменты', 'https://barn-estate.ru/gorodskaya-nedvizhimost/apartamenty/'], ['Пентхаусы', 'https://barn-estate.ru/kupit-penthausy-v-moskve/'], ['Застройщики', 'https://barn-estate.ru/zastroyshchiki/']]],
        ['Загородная', 'https://barn-estate.ru/zagorodnaya-nedvizhimost/', [['Купить', 'https://barn-estate.ru/zagorodnaya-nedvizhimost/'], ['Снять', 'https://barn-estate.ru/snyat-zagorodnuyu-nedvizhimost/'], ['Коттеджные поселки', 'https://barn-estate.ru/kottedzhnye-poselki/']]],
        ['Коммерческая', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/', [['Купить', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/'], ['Снять', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/arendovat/'], ['Здания', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/zdanie/'], ['Бизнес-центры', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/business-center/'], ['Особняки', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/osobnyak/'], ['Арендный бизнес', 'https://barn-estate.ru/kommercheskaya-nedvizhimost/arendnyj-biznes/']]],
        ['Курортная', 'https://barn-estate.ru/kurortnaya/', [['Инвестиции', 'https://barn-estate.ru/media/tag/investitsii-v-kurortnuyu-nedvizhimost-rossii/'], ['Алтай', 'https://barn-estate.ru/altai/'], ['Архыз', 'https://barn-estate.ru/arhyz/'], ['Сочи', 'https://barn-estate.ru/sochi/']]],
        ['Зарубежная', 'https://barn-estate.ru/mezhdunarodnaya-nedvizhimost/', [['ОАЭ', 'https://barn-estate.ru/oae/'], ['Турция', 'https://barn-estate.ru/mezhdunarodnaya-nedvizhimost/turtsiya/'], ['Таиланд', 'https://barn-estate.ru/tailand/'], ['Бали', 'https://barn-estate.ru/zhilye-kompleksy-indonesia/'], ['Испания', 'https://barn-estate.ru/ispaniya/'], ['Италия', 'https://barn-estate.ru/italiya/'], ['Португалия', 'https://barn-estate.ru/portugaliya/'], ['Франция', 'https://barn-estate.ru/frantsiya/'], ['Оман', 'https://barn-estate.ru/oman/'], ['Жилые комплексы', 'https://barn-estate.ru/mezhdunarodnaya-nedvizhimost-zhilye-kompleksy/']]],
        ['Санкт-Петербург', 'https://barnes-spb.ru', [['Вторичная', 'https://barnes-spb.ru/gorodskaya-nedvizhimost/vtorichnaya-nedvizhimost/'], ['Новостройки', 'https://barnes-spb.ru/gorodskaya-nedvizhimost/novostroyki/'], ['Загородная', 'https://barnes-spb.ru/zagorodnaya-nedvizhimost/'], ['Коммерческая', 'https://barnes-spb.ru/kommercheskaya-nedvizhimost/'], ['Эксклюзив', 'https://barnes-spb.ru/exclusive/'], ['Апартаменты', 'https://barnes-spb.ru/gorodskaya-nedvizhimost/filter/type_immovables-is-apartamenty/'], ['Пентхаус', 'https://barnes-spb.ru/gorodskaya-nedvizhimost/filter/type_immovables-is-penthausy/']]],
        ['Медиа', 'https://barn-estate.ru/media/', [['Блог', 'https://barn-estate.ru/media/blog/'], ['Новости', 'https://barn-estate.ru/media/novosti/'], ['Вебинары и видео', 'https://barn-estate.ru/media/vebinary-i-video/'], ['Аналитика рынка', 'https://barn-estate.ru/media/analitika/'], ['Искусство жить', 'https://barn-estate.ru/media/stil-zhizni/'], ['Кейсы', 'https://barn-estate.ru/media/cases/'], ['Журнал', 'https://barn-estate.ru/zhurnaly/']]],
        ['О BARN Estate', 'https://barn-estate.ru/mir-barnes/', [['Контакты', 'https://barn-estate.ru/contacts/'], ['Партнерам', 'https://barn-estate.ru/for-partners/'], ['BARN Estate Club', 'https://barn-estate.ru/barnes-club/'], ['СМИ о нас', 'https://barn-estate.ru/novosti/smi-o-nas/'], ['Мероприятия', 'https://barn-estate.ru/novosti/meropriyatiya/'], ['Команда', 'https://barn-estate.ru/team/'], ['Вакансии', 'https://barn-estate.ru/vacancies/'], ['Стиль жизни', 'https://barn-estate.ru/stily-zhizni/']]],
        ['Собственникам', 'https://barn-estate.ru/sobstvennikam/', [['Продажа', 'https://barn-estate.ru/prodazha_sobstvennikam/'], ['Аренда', 'https://barn-estate.ru/arenda_sobstvennikam/']]]
      ];
      const nav = document.createElement('nav');
      nav.className = 'site-header__nav';
      nav.setAttribute('aria-label', 'Основное меню');
      nav.setAttribute('data-v-7912d681', '');
      nav.innerHTML = '<ul class="site-header__nav-list" data-v-7912d681>' + items.map(function (item) {
        const subnav = '<ul class="site-header__subnav" data-v-7912d681>' + item[2].map(function (subitem) {
          return '<li data-v-7912d681><a class="site-header__subnav-link" href="' + subitem[1] + '" data-v-7912d681>' + subitem[0] + '</a></li>';
        }).join('') + '</ul>';
        return '<li class="site-header__nav-item owner-sale-nav-item" data-v-7912d681><a class="site-header__nav-link" href="' + item[1] + '" data-v-7912d681>' + item[0] + '</a>' + subnav + '</li>';
      }).join('') + '</ul>';
      inner.appendChild(nav);
    }

    const right = inner.querySelector('.site-header__right');
    const phone = right && right.querySelector('.site-header__phone');
    if (!right || !phone || right.querySelector('.owner-sale-hero-contacts')) return;

    const contacts = document.createElement('nav');
    contacts.className = 'owner-sale-hero-contacts';
    contacts.setAttribute('aria-label', 'Способы связи');
    [
      ['WhatsApp', 'https://wa.me/79252621650', '../assets/shared/whatsapp.svg'],
      ['MAX', 'https://max.ru/join/AWj8ibiCtAPOJOlulMGNkykKGz_prXVWg-IQK1KpUG8', '../assets/shared/max.svg'],
      ['Telegram', 'https://t.me/art_de_vivre_barnes', '../assets/shared/telegram.svg']
    ].forEach(function (item) {
      const link = document.createElement('a');
      const icon = document.createElement('img');
      link.className = 'owner-sale-hero-contact';
      link.href = item[1];
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.setAttribute('aria-label', 'Написать в ' + item[0]);
      icon.src = item[2];
      icon.alt = '';
      icon.setAttribute('aria-hidden', 'true');
      link.appendChild(icon);
      contacts.appendChild(link);
    });
    phone.classList.add('owner-sale-hero-contact', 'owner-sale-hero-contact--phone');
    phone.setAttribute('aria-label', 'Позвонить по номеру +7 495 182-50-79');
    contacts.appendChild(phone);
    right.appendChild(contacts);
  };

  enhanceHeroHeader();

  const enhanceAmbassadorsLink = function () {
    const label = 'Амбассадоры';
    const href = 'https://barn-estate.ru/for-partners/';

    document.querySelectorAll('.site-footer__column').forEach(function (column) {
      const title = column.querySelector('.site-footer__column-title');
      const links = column.querySelector('.site-footer__links');
      if (!title || !links || title.textContent.trim().toUpperCase() !== 'СОБСТВЕННИКАМ') return;
      if (Array.from(links.querySelectorAll('a')).some(function (link) {
        return link.textContent.trim() === label;
      })) return;

      const sampleItem = links.querySelector(':scope > li');
      const item = sampleItem ? sampleItem.cloneNode(true) : document.createElement('li');
      let link = item.querySelector('a');
      if (!link) {
        link = document.createElement('a');
        link.className = 'site-footer__link';
        item.appendChild(link);
      }
      link.textContent = label;
      link.href = href;
      link.removeAttribute('aria-current');
      links.appendChild(item);
    });
  };

  enhanceAmbassadorsLink();

  const magazineSection = page.querySelector(':scope > .owner-sale-magazine');
  if (magazineSection) magazineSection.remove();

  const enhanceSectionEyebrows = function () {
    [
      ['.owner-sale-stages__title', 'КАК ПРОХОДИТ СДЕЛКА'],
      ['.owner-sale-strategy__title', 'СТРАТЕГИЯ BARN Estate'],
      ['.owner-sale-presentation__title', 'СТРАТЕГИЯ ПРЕЗЕНТАЦИИ'],
      ['.about-company__title', 'BARN Estate / МОСКВА'],
    ].forEach(function (item) {
      const title = document.querySelector(item[0]);
      const container = title && title.parentElement;
      if (!title || !container || container.querySelector(':scope > .owner-sale-section-eyebrow')) return;

      const eyebrow = document.createElement('p');
      eyebrow.className = 'owner-sale-section-eyebrow';
      eyebrow.textContent = item[1];
      container.insertBefore(eyebrow, title);
    });

    const services = document.querySelector('.owner-sale-services__header-wrap');
    const servicesHeader = services && services.querySelector(':scope > .owner-sale-services__header');
    if (services && servicesHeader && !services.querySelector(':scope > .owner-sale-section-eyebrow')) {
      const eyebrow = document.createElement('p');
      eyebrow.className = 'owner-sale-section-eyebrow owner-sale-services__eyebrow';
      eyebrow.textContent = 'СОПРОВОЖДЕНИЕ СДЕЛКИ';
      services.insertBefore(eyebrow, servicesHeader);
    }

    const typesSection = document.querySelector('.owner-sale-types');
    const typesInner = typesSection && typesSection.querySelector('.owner-sale-types__inner');
    if (typesSection && typesInner && !typesInner.querySelector(':scope > .owner-sale-types__header')) {
      const header = document.createElement('header');
      header.className = 'owner-sale-types__header';
      header.innerHTML = '<p class="owner-sale-section-eyebrow owner-sale-types__eyebrow">НАПРАВЛЕНИЯ BARN Estate</p><h2 class="owner-sale-types__section-title" id="owner-sale-types-title">ПОМОЖЕМ ПРОДАТЬ ВАШУ НЕДВИЖИМОСТЬ</h2>';
      typesInner.insertBefore(header, typesInner.firstChild);
      typesSection.setAttribute('aria-labelledby', 'owner-sale-types-title');
      typesSection.removeAttribute('aria-label');
    }
  };

  enhanceSectionEyebrows();

  const enhanceFormAccessibility = function () {
    const fieldMap = [
      ['.catalog-consultation__input', ['Ваше имя', 'Номер телефона']],
    ];

    fieldMap.forEach(function (item) {
      page.querySelectorAll(item[0]).forEach(function (field, index) {
        if (!field.hasAttribute('aria-label')) field.setAttribute('aria-label', item[1][index] || 'Контактное поле');
        if (index === 1 && field.type === 'text') field.type = 'tel';
        if (index === 0 && !field.hasAttribute('autocomplete')) field.setAttribute('autocomplete', 'name');
        if (index === 1 && !field.hasAttribute('autocomplete')) field.setAttribute('autocomplete', 'tel');
      });
    });

    page.querySelectorAll('.catalog-consultation__textarea').forEach(function (field) {
      if (!field.hasAttribute('aria-label')) field.setAttribute('aria-label', 'Комментарий');
    });

    page.querySelectorAll('.catalog-consultation__consent-input').forEach(function (field) {
      if (!field.hasAttribute('aria-label')) field.setAttribute('aria-label', 'Согласие на обработку персональных данных');
    });

    document.querySelectorAll('.newsletter-form input[type="email"]').forEach(function (field) {
      if (!field.hasAttribute('aria-label')) field.setAttribute('aria-label', 'Ваш email');
    });
  };

  enhanceFormAccessibility();

  const reorderSaleSections = function () {
    const hero = page.querySelector(':scope > .owner-sale-hero');
    if (!hero) return;

    const orderedSections = [
      page.querySelector(':scope > .owner-sale-types'),
      page.querySelector(':scope > .owner-sale-services'),
      page.querySelector(':scope > .owner-sale-strategy')
    ].filter(Boolean);

    let insertionPoint = hero.nextSibling;
    orderedSections.forEach(function (section) {
      page.insertBefore(section, insertionPoint);
      insertionPoint = section.nextSibling;
    });
  };

  reorderSaleSections();

  const enhancePresentationCards = function () {
    const descriptions = [
      'Находим сильные стороны объекта и превращаем их в понятные преимущества для будущего покупателя.',
      'Определяем позиционирование, ценовой ориентир и ключевые акценты для презентации объекта.',
      'Выбираем релевантные каналы и показываем объект аудитории, которая соответствует его уровню.',
      'Берём на себя коммуникацию с покупателями и защищаем интересы собственника на каждом этапе переговоров.',
      'Проверяем документы и сопровождаем сделку, чтобы обеспечить её юридическую чистоту и безопасность.',
      'Контролируем доступ к информации об объекте и проводим просмотры с учётом требований собственника.'
    ];

    page.querySelectorAll('.owner-sale-presentation__card').forEach(function (card, index) {
      const caption = card.querySelector('.owner-sale-presentation__caption');
      if (!caption || card.querySelector('.owner-sale-presentation__reveal')) return;

      const reveal = document.createElement('div');
      const text = document.createElement('p');
      reveal.className = 'owner-sale-presentation__reveal';
      text.className = 'owner-sale-presentation__reveal-text';
      text.id = 'owner-sale-presentation-description-' + (index + 1);
      text.textContent = descriptions[index];
      caption.parentNode.insertBefore(reveal, caption);
      reveal.append(caption, text);
      card.tabIndex = 0;
      card.setAttribute('aria-describedby', text.id);
    });
  };

  enhancePresentationCards();

  const enhanceSaleStages = function () {
    const section = page.querySelector('.owner-sale-stages');
    const aside = section && section.querySelector('.owner-sale-stages__aside');
    const title = section && section.querySelector('.owner-sale-stages__title');
    const offer = section && section.querySelector('.owner-sale-stages__offer');
    const offerText = offer && offer.querySelector('.owner-sale-stages__offer-text');
    const offerButton = offer && offer.querySelector('.owner-sale-stages__offer-btn');
    if (!section || !aside || !title) return;

    title.id = 'owner-sale-stages-title';
    section.setAttribute('aria-labelledby', title.id);
    section.removeAttribute('aria-label');
    aside.classList.add('owner-sale-stages__header');

    if (offerText && !aside.querySelector('.owner-sale-stages__intro')) {
      offerText.className = 'owner-sale-stages__intro';
      aside.appendChild(offerText);
    }
    if (offerButton) {
      offerButton.classList.add('owner-sale-stages__cta');
      aside.appendChild(offerButton);
    }
    if (offer) offer.remove();
  };

  enhanceSaleStages();

  let stagesScrollFrame = null;
  const updateStagesScrollState = function () {
    const section = page.querySelector('.owner-sale-stages');
    const items = section && Array.from(section.querySelectorAll('.owner-sale-stages__item'));
    const headerBlock = section && section.querySelector('.owner-sale-stages__header');
    const desktop = window.matchMedia('(min-width: 901px)').matches;
    if (!section || !items.length) return;

    if (!desktop) {
      section.classList.remove('owner-sale-stages--scroll-ready');
      items.forEach(function (item) {
        item.classList.remove('is-active', 'is-past');
        item.style.removeProperty('--owner-sale-stages-last-offset');
      });
      return;
    }

    let alignmentLine = headerBlock ? parseFloat(window.getComputedStyle(headerBlock).top) : 120;
    if (!Number.isFinite(alignmentLine)) alignmentLine = 120;
    const lastItem = items[items.length - 1];
    const currentLastOffset = parseFloat(lastItem.style.getPropertyValue('--owner-sale-stages-last-offset')) || 0;
    const naturalLastTop = lastItem.getBoundingClientRect().top - currentLastOffset;
    const headerTop = headerBlock ? headerBlock.getBoundingClientRect().top : alignmentLine;
    const lastOffset = Math.max(0, headerTop - naturalLastTop);
    lastItem.style.setProperty('--owner-sale-stages-last-offset', lastOffset + 'px');

    let activeIndex = 0;
    let closestDistance = Infinity;
    items.forEach(function (item, index) {
      const distance = Math.abs(item.getBoundingClientRect().top - alignmentLine);
      if (distance < closestDistance) {
        closestDistance = distance;
        activeIndex = index;
      }
    });

    section.classList.add('owner-sale-stages--scroll-ready');
    items.forEach(function (item, index) {
      item.classList.toggle('is-active', index === activeIndex);
      item.classList.toggle('is-past', index < activeIndex);
    });
  };

  const requestStagesScrollUpdate = function () {
    if (stagesScrollFrame) return;
    stagesScrollFrame = window.requestAnimationFrame(function () {
      stagesScrollFrame = null;
      updateStagesScrollState();
    });
  };

  window.addEventListener('scroll', requestStagesScrollUpdate, { passive: true });
  window.addEventListener('resize', requestStagesScrollUpdate, { passive: true });
  requestStagesScrollUpdate();

  const enhanceStickyHeader = function () {
    const inner = sticky && sticky.querySelector('.owner-sale-sticky__inner');
    const nav = inner && inner.querySelector('.owner-sale-sticky__nav');
    const list = nav && nav.querySelector('.owner-sale-sticky__list');
    const brand = inner && inner.querySelector('.owner-sale-sticky__brand');
    const logo = brand && brand.querySelector('.owner-sale-sticky__logo');
    const phone = brand && brand.querySelector('.owner-sale-sticky__phone');
    if (!sticky || !inner || !list || !brand || !phone) return;

    const presentation = page.querySelector('.owner-sale-presentation');
    const services = page.querySelector('.owner-sale-services');
    const about = page.querySelector('.about-company');
    if (presentation) presentation.id = 'presentation';
    if (services) services.id = 'services';
    if (about) about.id = 'team';

    if (logo && logo.parentElement !== inner) inner.insertBefore(logo, brand);

    if (!brand.querySelector('.owner-sale-sticky__request')) {
      const request = document.createElement('button');
      request.className = 'owner-sale-sticky__request';
      request.type = 'button';
      request.textContent = 'Оставить заявку';
      brand.insertBefore(request, phone);
    }

    if (!brand.querySelector('.owner-sale-sticky__messengers')) {
      const messengers = document.createElement('nav');
      messengers.className = 'owner-sale-sticky__messengers';
      messengers.setAttribute('aria-label', 'Способы связи');
      [
        ['WhatsApp', 'https://wa.me/79252621650', '../assets/shared/whatsapp.svg'],
        ['MAX', 'https://max.ru/join/AWj8ibiCtAPOJOlulMGNkykKGz_prXVWg-IQK1KpUG8', '../assets/shared/max.svg'],
        ['Telegram', 'https://t.me/art_de_vivre_barnes', '../assets/shared/telegram.svg']
      ].forEach(function (item) {
        const link = document.createElement('a');
        const icon = document.createElement('img');
        link.className = 'owner-sale-sticky__messenger';
        link.href = item[1];
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.setAttribute('aria-label', 'Написать в ' + item[0]);
        icon.src = item[2];
        icon.alt = '';
        icon.setAttribute('aria-hidden', 'true');
        link.appendChild(icon);
        messengers.appendChild(link);
      });
      brand.insertBefore(messengers, phone);
    }

    const messengers = brand.querySelector('.owner-sale-sticky__messengers');
    phone.setAttribute('aria-label', 'Позвонить по номеру +7 495 182-50-79');
    if (messengers && phone.parentElement !== messengers) messengers.appendChild(phone);

    list.innerHTML = [
      ['Услуги', 'property-types'],
      ['Преимущества', 'why-barnes'],
      ['Как работаем', 'services'],
      ['Консультация', 'request']
    ].map(function (item) {
      return '<li class="owner-sale-sticky__item"><a class="owner-sale-sticky__link" href="#' + item[1] + '">' + item[0] + '</a></li>';
    }).join('') + '<li class="owner-sale-sticky__item owner-sale-sticky__item--contacts"><button class="owner-sale-sticky__contact-toggle" type="button" aria-expanded="false" aria-controls="owner-sale-sticky-contacts" aria-label="Показать способы связи"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.5 9.8 9.8 0 0 1-4-.9L3 21l1.7-4.6A8.4 8.4 0 1 1 21 11.5Z"></path><path d="M8 12h.01M12 12h.01M16 12h.01"></path></svg></button></li>';

    let panel = inner.querySelector('.owner-sale-sticky__contact-panel');
    if (!panel && messengers) {
      panel = messengers.cloneNode(true);
      panel.id = 'owner-sale-sticky-contacts';
      panel.className = 'owner-sale-sticky__contact-panel';
      panel.hidden = true;
      inner.appendChild(panel);
    }

    const toggle = list.querySelector('.owner-sale-sticky__contact-toggle');
    if (toggle && panel) {
      toggle.dataset.bound = 'true';
      toggle.addEventListener('click', function () {
        const open = panel.hidden;
        panel.hidden = !open;
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Скрыть способы связи' : 'Показать способы связи');
      });
    }
  };

  enhanceStickyHeader();

  page.querySelectorAll('.owner-sale-types__action').forEach(function (action) {
    if (action.querySelector('.owner-sale-types__action-icon')) return;
    const icon = document.createElement('span');
    icon.className = 'owner-sale-types__action-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.innerHTML = '<svg viewBox="0 0 16 16" focusable="false"><path d="M3 13 13 3M5 3h8v8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.25"></path></svg>';
    action.appendChild(icon);
  });

  if (!menu && menuButton) {
    menu = document.createElement('aside');
    menu.className = 'owner-sale-clone-menu';
    menu.setAttribute('hidden', '');
    menu.innerHTML = '<div class="owner-sale-clone-menu__inner"><button class="owner-sale-clone-menu__close" type="button" aria-label="Закрыть меню">×</button><nav aria-label="Навигация"><a href="#property-types">Наши услуги</a><a href="#why-barnes">Преимущества</a><a href="#services">Как мы работаем</a><a href="#request">Получить консультацию</a></nav><a class="owner-sale-clone-menu__phone" href="tel:74951825079">+7 (495) 182-50-79</a></div>';
    document.body.appendChild(menu);
    menu.querySelector('.owner-sale-clone-menu__close').addEventListener('click', function () {
      menu.setAttribute('hidden', '');
      menuButton.setAttribute('aria-expanded', 'false');
      unlockBodyScroll();
    });
  }

  if (!document.querySelector('.floating-expert')) {
    const expert = document.createElement('aside');
    expert.className = 'floating-expert floating-expert--gorodskaya';
    expert.setAttribute('aria-label', 'Руслан Прус');
    expert.innerHTML = '<button type="button" class="floating-expert__card" aria-haspopup="dialog"><span class="floating-expert__avatar"><img src="../assets/ruslan.webp" alt="Руслан Прус" width="72" height="72" loading="lazy" decoding="async"></span><span class="floating-expert__content"><span class="floating-expert__label">Руководитель департамента городской недвижимости</span><span class="floating-expert__title">Задать вопрос эксперту</span><span class="floating-expert__name">Руслан Прус</span></span></button><button type="button" class="floating-expert__close" aria-label="Скрыть карточку Руслан Прус"></button>';
    expert.querySelectorAll('*').forEach(function (element) {
      element.setAttribute('data-v-cd0a1259', '');
    });
    expert.setAttribute('data-v-cd0a1259', '');
    document.body.appendChild(expert);

    expert.querySelector('.floating-expert__close').addEventListener('click',function(event){event.stopPropagation();expert.remove();});
  }

  page.querySelectorAll('.owner-sale-services__slider-wrap').forEach(function (wrap) {
    const placeholder = wrap.querySelector(':scope > span');
    if (!placeholder || placeholder.children.length) return;

    const services = [
      'Анализируем рынок, характеристики объекта и определяем оптимальную стоимость продажи или аренды.',
      'Разрабатываем план продвижения с учётом особенностей недвижимости, целевой аудитории и задач собственника.',
      'Готовим объект к выходу на рынок, создаём презентационные материалы и используем собственные каналы продвижения BARN Estate.',
      'Представляем объект подходящей аудитории, организуем показы и проводим переговоры с заинтересованными клиентами.',
      'Согласовываем условия, координируем подготовку документов и сопровождаем сделку до её завершения.'
    ];
    const serviceTitles = [
      'Оценка недвижимости',
      'Индивидуальная стратегия',
      'Презентация и продвижение',
      'Поиск покупателей и арендаторов',
      'Сопровождение сделки'
    ];
    const slider = document.createElement('div');
    slider.className = 'splide owner-sale-services__slider is-overflow is-initialized splide--slide splide--ltr splide--draggable is-active';
    slider.setAttribute('data-v-2d6c67d9', '');
    slider.setAttribute('role', 'region');
    slider.setAttribute('aria-label', 'Пять этапов работы с собственниками');
    slider.tabIndex = 0;
    slider.innerHTML = '<div class="splide__track" data-v-2d6c67d9=""><ul class="splide__list" data-v-2d6c67d9="">' + services.map(function (service, index) {
      const number = String(index + 1).padStart(2, '0');
      return '<li class="splide__slide" data-v-2d6c67d9=""><article class="owner-sale-services__card" data-v-2d6c67d9=""><span class="owner-sale-services__number" data-v-2d6c67d9="">' + number + '</span><p class="owner-sale-services__text" data-v-2d6c67d9=""><strong>' + serviceTitles[index] + '</strong><span>' + service + '</span></p></article></li>';
    }).join('') + '</ul></div>';
    placeholder.replaceWith(slider);
  });

  syncMenuState();

  if (menuButton && menu) {
    menuButton.addEventListener('click', function () {
      const isOpen = menu.hasAttribute('hidden') === false;
      const nextOpen = !isOpen;
      menu.toggleAttribute('hidden', !nextOpen);
      if (header) header.classList.toggle('site-header--menu-open', nextOpen);
      if (nextOpen && header) {
        const headerHeight = header.getBoundingClientRect().height;
        document.documentElement.style.setProperty('--layout-header-height', headerHeight + 'px');
        document.documentElement.style.setProperty('--site-menu-top', headerHeight + 'px');
      } else {
        document.documentElement.style.removeProperty('--layout-header-height');
        document.documentElement.style.removeProperty('--site-menu-top');
      }
      menuButton.setAttribute('aria-label', nextOpen ? 'Закрыть меню' : 'Открыть меню');
      syncMenuState();
      menuButton.innerHTML = nextOpen
        ? '<span class="ui-icon ui-icon-current site-header__icon" data-v-7912d681 data-v-8bd2f545><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg></span>'
        : '<span class="ui-icon ui-icon-current site-header__icon" data-v-7912d681 data-v-8bd2f545><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M5 7h14"></path><path d="M5 12h14"></path><path d="M5 17h14"></path></svg></span>';
      if (nextOpen) lockBodyScroll();
      else unlockBodyScroll();
    });
  }

  document.querySelectorAll('.site-menu__close, .site-menu__overlay').forEach(function (control) {
    control.addEventListener('click', function () {
      if (!menu) return;
      menu.setAttribute('hidden', '');
      if (menuButton) {
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Открыть меню');
      }
      syncMenuState();
      unlockBodyScroll();
    });
  });

  const syncSticky = function () {
    if (!sticky) return;
    const hero = page.querySelector('.owner-sale-hero');
    const revealPoint = hero ? hero.offsetTop + hero.offsetHeight - 120 : window.innerHeight * 0.72;
    const visible = window.scrollY > revealPoint;
    sticky.classList.toggle('owner-sale-sticky--visible', visible);
    sticky.setAttribute('aria-hidden', String(!visible));
    sticky.toggleAttribute('inert', !visible);
    const links = Array.from(sticky.querySelectorAll('.owner-sale-sticky__link'));
    let activeLink = links[0];
    links.forEach(function (link) {
      const target = document.querySelector(link.getAttribute('href'));
      if (target && window.scrollY + 140 >= target.offsetTop) activeLink = link;
    });
    links.forEach(function (link) {
      link.classList.toggle('owner-sale-sticky__link--active', link === activeLink);
    });
  };
  window.addEventListener('scroll', syncSticky, { passive: true });
  syncSticky();

  page.querySelectorAll('.owner-sale-presentation__card').forEach(function (card, index) {
    card.setAttribute('tabindex', '0');
    const caption = card.querySelector('.owner-sale-presentation__caption, .owner-sale-presentation__featured-title');
    if (caption && !caption.id) caption.id = 'owner-sale-presentation-caption-' + (index + 1);
    if (caption) card.setAttribute('aria-labelledby', caption.id);
  });

  page.querySelectorAll('img:not(.owner-sale-hero__image)').forEach(function (image) {
    if (!image.hasAttribute('loading')) image.setAttribute('loading', 'lazy');
    if (!image.hasAttribute('decoding')) image.setAttribute('decoding', 'async');
  });

  document.querySelectorAll([
    '.owner-sale-strategy img',
    '.owner-sale-presentation img',
    '.catalog-consultation img',
    '.owner-sale-types img',
    '.newsletter-cta img'
  ].join(',')).forEach(function (image) {
    image.setAttribute('loading', 'eager');
  });

  document.querySelectorAll('a[target="_blank"]').forEach(function (link) {
    link.setAttribute('rel', 'noopener noreferrer');
  });

  page.querySelectorAll('.owner-sale-sticky__link').forEach(function (link) {
    link.addEventListener('click', function () {
      const targets = { Услуги: '#property-types', Преимущества: '#why-barnes', 'Как работаем': '#services', Консультация: '#request' };
      const target = document.querySelector(targets[link.textContent.trim()]);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  page.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (event) {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  page.querySelectorAll('.owner-sale-services').forEach(function (section) {
    const slider = section.querySelector('.owner-sale-services__slider');
    const list = slider && slider.querySelector('.splide__list');
    const previous = section.querySelector('.owner-sale-services__nav-btn:first-child');
    const next = section.querySelector('.owner-sale-services__nav-btn:last-child');
    if (!slider || !list || !previous || !next) return;

    let offset = 0;
    const step = function () {
      const card = list.querySelector('.splide__slide');
      return card ? card.getBoundingClientRect().width : 0;
    };
    const maxOffset = function () {
      return Math.max(0, list.scrollWidth - slider.querySelector('.splide__track').clientWidth);
    };
    const render = function () {
      list.style.transform = 'translateX(' + (-offset) + 'px)';
      slider.setAttribute('aria-description', 'Используйте стрелки влево и вправо для просмотра пяти этапов.');
      previous.disabled = offset <= 0;
      next.disabled = offset >= maxOffset() - 1;
    };
    previous.addEventListener('click', function () {
      offset = Math.max(0, offset - step());
      render();
    });
    next.addEventListener('click', function () {
      offset = Math.min(maxOffset(), offset + step());
      render();
    });
    slider.addEventListener('keydown', function (event) {
      if (event.target !== slider) return;
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      if (event.key === 'Home') offset = 0;
      else if (event.key === 'End') offset = maxOffset();
      else offset = Math.min(maxOffset(), Math.max(0, offset + (event.key === 'ArrowRight' ? 1 : -1) * step()));
      render();
    });
    let touchStart = null;
    slider.addEventListener('touchstart', function (event) { touchStart = event.touches[0].clientX; }, { passive: true });
    slider.addEventListener('touchend', function (event) {
      if (touchStart === null) return;
      const delta = touchStart - event.changedTouches[0].clientX;
      touchStart = null;
      if (Math.abs(delta) < 40) return;
      offset = Math.min(maxOffset(), Math.max(0, offset + (delta > 0 ? 1 : -1) * step()));
      render();
    }, { passive: true });
    window.addEventListener('resize', function () {
      offset = Math.min(offset, maxOffset());
      render();
    });
    render();
  });

  page.querySelectorAll('[role="tablist"]').forEach(function (tablist) {
    const tabs = Array.from(tablist.querySelectorAll('[role="tab"]'));
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        tabs.forEach(function (item) {
          item.setAttribute('aria-selected', String(item === tab));
          const itemMethodClass = Array.from(item.classList).find(function (className) {
            return className.endsWith('__method') || className.endsWith('__method--active');
          });
          const baseMethodClass = itemMethodClass?.replace(/--active$/, '');
          if (baseMethodClass) item.className = item === tab ? baseMethodClass + '--active ' + baseMethodClass : baseMethodClass;
        });
      });
    });
  });

  const moreButton = page.querySelector('.ui-more-link[aria-controls="about-company-more"]');
  const moreCopy = document.querySelector('#about-company-more');
  if (moreButton && moreCopy) {
    moreButton.addEventListener('click', function () {
      const expanded = moreButton.getAttribute('aria-expanded') === 'true';
      moreButton.setAttribute('aria-expanded', String(!expanded));
      moreButton.querySelector('.ui-more-link__label').textContent = expanded ? 'Читать далее' : 'Свернуть';
      const copy = moreCopy.closest('.about-company__copy');
      if (copy) copy.classList.toggle('about-company__copy--open', !expanded);
    });
  }

  page.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const submit = form.querySelector('button[type="submit"], button');
      if (!submit) return;
      const original = submit.textContent;
      submit.textContent = 'Спасибо, заявка отправлена';
      submit.disabled = true;
      window.setTimeout(function () {
        submit.textContent = original;
        submit.disabled = false;
      }, 2600);
    });
  });

  document.querySelectorAll('.floating-expert__close').forEach(function (close) {
    close.addEventListener('click', function (event) {
      event.stopPropagation();
      const card = close.closest('.floating-expert');
      if (card) card.remove();
    });
  });
}());
